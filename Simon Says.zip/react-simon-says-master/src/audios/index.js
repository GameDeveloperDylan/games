import blueTone from './blue.mp3';
import greenTone from './green.mp3';
import redTone from './red.mp3';
import yellowTone from './yellow.mp3';

export default {
  blue: blueTone,
  green: greenTone,
  red: redTone,
  yellow: yellowTone,
}
